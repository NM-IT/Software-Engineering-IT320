<?php
// ===========================
//  Darbic — Get Notifications
//  GET: visitor_id
// ===========================

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once 'config.php';

$visitor_id = intval($_GET['visitor_id'] ?? 0);

if ($visitor_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid visitor ID"]);
    exit;
}

$sql = "
    SELECT notification_id, title, message, is_read, sent_at
    FROM notification
    WHERE visitor_id = ?
    ORDER BY sent_at DESC
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $visitor_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$notifications = [];

while ($row = mysqli_fetch_assoc($result)) {

    $sent = new DateTime($row['sent_at']);
    $now  = new DateTime();
    $diff = $now->diff($sent);

    if ($diff->days >= 1) {
        $time_label = $diff->days . " day" . ($diff->days > 1 ? "s" : "") . " ago";
    } elseif ($diff->h >= 1) {
        $time_label = $diff->h . " hour" . ($diff->h > 1 ? "s" : "") . " ago";
    } elseif ($diff->i >= 1) {
        $time_label = $diff->i . " minute" . ($diff->i > 1 ? "s" : "") . " ago";
    } else {
        $time_label = "Just now";
    }

    $notifications[] = [
        "id"      => $row['notification_id'],
        "title"   => $row['title'],
        "message" => $row['message'],
        "is_read" => (bool)$row['is_read'],
        "time"    => $time_label
    ];
}

echo json_encode(["success" => true, "notifications" => $notifications]);

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>