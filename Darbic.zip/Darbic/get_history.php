<?php
// ===========================
//  Darbic — Event History
//  GET: visitor_id
// ===========================

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once 'config.php';

$visitor_id = intval($_GET['visitor_id'] ?? 0);

if ($visitor_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid visitor ID"]);
    exit;
}

$sql = "
    SELECT 
        e.event_name,
        g.gate_name,
        va.pickup_point,
        va.arrival_time,
        eh.attended_date
    FROM eventhistory eh
    JOIN event e              ON eh.event_id      = e.event_id
    JOIN visitorassignment va ON eh.assignment_id = va.assignment_id
    JOIN gate g               ON va.gate_id        = g.gate_id
    WHERE eh.visitor_id = ?
    ORDER BY eh.attended_date DESC
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $visitor_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$history = [];

while ($row = mysqli_fetch_assoc($result)) {
    $history[] = [
        "event_name"   => $row['event_name'],
        "gate"         => $row['gate_name']    ?? '-',
        "pickup_point" => $row['pickup_point'] ?? '-',
        "arrival_time" => $row['arrival_time']
                            ? date("g:i A", strtotime($row['arrival_time']))
                            : '-',
        "date"         => $row['attended_date']
                            ? date("d M Y", strtotime($row['attended_date']))
                            : '-'
    ];
}

echo json_encode([
    "success"      => true,
    "total_events" => count($history),
    "last_event"   => count($history) > 0 ? $history[0]['event_name'] : null,
    "history"      => $history
]);

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>