<?php session_start(); ?>

var VISITOR_ID = <?php echo $_SESSION['visitor_id'] ?? 0; ?>;

let lastTicketNumber = "";

// ============================================================
//  1. Submit Ticket
// ============================================================
function submitTicket(btn) {
    let ticket = document.getElementById("ticketInput").value.trim();

    if (ticket === "") {
        alert("Please enter ticket number");
        return;
    }

    btn.classList.add("loading");
    btn.innerHTML = `<div class="spinner"></div> Processing...`;

    const formData = new FormData();
    formData.append("ticket_id", ticket);

    fetch("submit_ticket.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        btn.classList.remove("loading");
        btn.innerHTML = "🚀 Submit Ticket";

        if (!data.success) {
            alert(data.message);
            return;
        }

        lastTicketNumber = ticket;

        document.getElementById("gate").innerText   = data.gate;
        document.getElementById("time").innerText   = data.arrival_time;
        document.getElementById("pickup").innerText = data.pickup;
        document.getElementById("saved").innerText  = data.time_saved;

        showSection("assignment");

        document.querySelectorAll(".card.small").forEach((c, i) => {
            c.style.animation = "cardAppear .5s forwards";
            c.style.animationDelay = (i * 0.1) + "s";
        });

        document.getElementById("emptyState").style.display       = "none";
        document.getElementById("assignmentContent").style.display = "block";
    })
    .catch(err => {
        btn.classList.remove("loading");
        btn.innerHTML = "🚀 Submit Ticket";
        alert("Connection error. Please try again.");
        console.error(err);
    });
}

// ============================================================
//  2. Update Profile
// ============================================================
document.querySelector("#profile form")?.addEventListener("submit", function(e) {
    e.preventDefault();

    const formData = new FormData();
    formData.append("visitor_id", VISITOR_ID);
    formData.append("full_name",  document.getElementById("visitorName").value.trim());
    formData.append("email",      document.getElementById("visitorEmail").value.trim());
    formData.append("phone",      document.getElementById("visitorPhone").value.trim());

    fetch("update_profile.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => alert(data.message))
    .catch(() => alert("Connection error"));
});

// ============================================================
//  3. Assistance Toggle
// ============================================================
document.getElementById("assistCheck")?.addEventListener("change", function() {
    const action   = this.checked ? "request" : "cancel";
    const textEl   = document.getElementById("assistText");
    const checkbox = this;

    const formData = new FormData();
    formData.append("visitor_id",    VISITOR_ID);
    formData.append("ticket_number", lastTicketNumber);
    formData.append("action",        action);

    fetch("assistance_request.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (!data.success) {
            alert(data.message);
            checkbox.checked = !checkbox.checked;
            return;
        }

        if (checkbox.checked) {
            textEl.innerHTML = 'Requested <span class="tick show">✔</span>';
            textEl.classList.add("active", "vibrate");
            setTimeout(() => textEl.classList.remove("vibrate"), 200);
        } else {
            textEl.innerHTML = 'Request Golf Cart Assistance <span id="tick" class="tick">✔</span>';
            textEl.classList.remove("active");
        }
    })
    .catch(() => alert("Connection error"));
});

// ============================================================
//  4. Load Notifications
// ============================================================
function loadNotifications() {
    fetch(`get_notifications.php?visitor_id=${VISITOR_ID}`)
    .then(res => res.json())
    .then(data => {
        if (!data.success || data.notifications.length === 0) return;

        const list = document.querySelector(".notifications-list");
        if (!list) return;
        list.innerHTML = "";

        data.notifications.forEach(n => {
            const unreadClass = n.is_read ? "" : "unread";
            list.innerHTML += `
            <div class="notification-item ${unreadClass}">
                <div class="notification-icon">${n.is_read ? "ℹ️" : "🔔"}</div>
                <div class="notification-content">
                    <h4>${n.title}</h4>
                    <p>${n.message}</p>
                    <span class="notification-time">${n.time}</span>
                </div>
            </div>`;
        });
    })
    .catch(console.error);
}

loadNotifications();

// ============================================================
//  5. Load Event History
// ============================================================
function loadHistory() {
    fetch(`get_history.php?visitor_id=${VISITOR_ID}`)
    .then(res => res.json())
    .then(data => {
        if (!data.success) return;

        const statCards = document.querySelectorAll(".history-stat-card p");
        if (statCards.length >= 2) {
            statCards[0].innerText = data.total_events;
            statCards[1].innerText = data.last_event ?? "-";
        }

        const tbody = document.querySelector(".history-table tbody");
        if (!tbody) return;
        tbody.innerHTML = "";

        data.history.forEach(h => {
            tbody.innerHTML += `
            <tr>
                <td>${h.event_name}</td>
                <td>${h.gate}</td>
                <td>${h.pickup_point}</td>
                <td>${h.arrival_time}</td>
                <td>${h.date}</td>
            </tr>`;
        });
    })
    .catch(console.error);
}

loadHistory();

// ============================================================
//  6. Delete Account
// ============================================================
document.querySelector(".delete-btn")?.addEventListener("click", function() {
    if (!confirm("Are you sure you want to delete your account? This cannot be undone.")) return;

    const formData = new FormData();
    formData.append("visitor_id", VISITOR_ID);

    fetch("delete_account.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            window.location.href = "index.html";
        }
    })
    .catch(() => alert("Connection error"));
});