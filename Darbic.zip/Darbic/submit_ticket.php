<?php
// ===========================
//  Darbic — Submit Ticket
//  POST: ticket_id (ticket_number)
// ===========================

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

$ticket_number = trim($_POST['ticket_id'] ?? '');

if (empty($ticket_number)) {
    echo json_encode(["success" => false, "message" => "Ticket ID is required"]);
    exit;
}

// جلب التكت + الأسايمنت + البوابة + التايم سلوت
$sql = "
    SELECT 
        t.ticket_id,
        t.ticket_number,
        t.ticket_type,
        t.status,
        e.event_name,
        va.pickup_point,
        va.arrival_time,
        va.departure_time,
        va.guidance_instructions,
        g.gate_name,
        z.zone_name,
        ts.start_time,
        ts.end_time
    FROM ticket t
    JOIN visitorassignment va ON t.ticket_id   = va.ticket_id
    JOIN gate g               ON va.gate_id     = g.gate_id
    JOIN zone z               ON va.zone_id     = z.zone_id
    JOIN timeslot ts          ON va.timeslot_id = ts.timeslot_id
    JOIN event e              ON t.event_id     = e.event_id
    WHERE t.ticket_number = ?
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $ticket_number);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    echo json_encode(["success" => false, "message" => "Ticket not found"]);
    exit;
}

$row = mysqli_fetch_assoc($result);

if ($row['status'] !== 'Active') {
    echo json_encode(["success" => false, "message" => "Ticket is not active"]);
    exit;
}

$arrival   = strtotime($row['arrival_time']);
$departure = strtotime($row['departure_time']);
$saved_mins = round(abs($departure - $arrival) / 60);

echo json_encode([
    "success"       => true,
    "gate"          => $row['gate_name'],
    "arrival_time"  => date("g:i A", strtotime($row['arrival_time'])),
    "pickup"        => $row['pickup_point'],
    "time_saved"    => $saved_mins . " mins",
    "ticket_type"   => $row['ticket_type'],
    "event_name"    => $row['event_name'],
    "zone"          => $row['zone_name'],
    "instructions"  => $row['guidance_instructions']
]);

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>