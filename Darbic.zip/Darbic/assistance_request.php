<?php
// ===========================
//  Darbic — Assistance Request
//  POST: visitor_id, ticket_number, action (request | cancel)
// ===========================

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

$visitor_id    = intval(trim($_POST['visitor_id']    ?? 0));
$ticket_number = trim($_POST['ticket_number'] ?? '');
$action        = trim($_POST['action']        ?? 'request');

if ($visitor_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid visitor ID"]);
    exit;
}

// bring ticket_id from ticket_number
$tStmt = mysqli_prepare($conn, "SELECT ticket_id FROM ticket WHERE ticket_number = ? AND visitor_id = ?");
mysqli_stmt_bind_param($tStmt, "si", $ticket_number, $visitor_id);
mysqli_stmt_execute($tStmt);
$tResult = mysqli_stmt_get_result($tStmt);
$ticketRow = mysqli_fetch_assoc($tResult);
mysqli_stmt_close($tStmt);

if (!$ticketRow) {
    echo json_encode(["success" => false, "message" => "Ticket not found for this visitor"]);
    exit;
}

$ticket_id = $ticketRow['ticket_id'];

// check if there any request
$check = mysqli_prepare($conn, "SELECT request_id, request_status FROM assistancerequest WHERE visitor_id = ? AND ticket_id = ?");
mysqli_stmt_bind_param($check, "ii", $visitor_id, $ticket_id);
mysqli_stmt_execute($check);
$cResult  = mysqli_stmt_get_result($check);
$existing = mysqli_fetch_assoc($cResult);
mysqli_stmt_close($check);

if ($action === 'request') {

    if ($existing) {
        if ($existing['request_status'] === 'Cancelled') {
            $upd = mysqli_prepare($conn, "UPDATE assistancerequest SET request_status='Pending' WHERE request_id=?");
            mysqli_stmt_bind_param($upd, "i", $existing['request_id']);
            mysqli_stmt_execute($upd);
            mysqli_stmt_close($upd);
            echo json_encode(["success" => true, "message" => "Assistance request resubmitted"]);
        } else {
            echo json_encode(["success" => true, "message" => "Assistance already requested"]);
        }
    } else {
        $ins = mysqli_prepare($conn, "INSERT INTO assistancerequest (request_type, request_status, visitor_id, ticket_id) VALUES ('Golf Cart', 'Pending', ?, ?)");
        mysqli_stmt_bind_param($ins, "ii", $visitor_id, $ticket_id);
        mysqli_stmt_execute($ins);
        mysqli_stmt_close($ins);
        echo json_encode(["success" => true, "message" => "Assistance request submitted"]);
    }

} elseif ($action === 'cancel') {

    if ($existing) {
        $upd = mysqli_prepare($conn, "UPDATE assistancerequest SET request_status='Cancelled' WHERE request_id=?");
        mysqli_stmt_bind_param($upd, "i", $existing['request_id']);
        mysqli_stmt_execute($upd);
        mysqli_stmt_close($upd);
        echo json_encode(["success" => true, "message" => "Assistance request cancelled"]);
    } else {
        echo json_encode(["success" => false, "message" => "No active request found"]);
    }

} else {
    echo json_encode(["success" => false, "message" => "Invalid action"]);
}

mysqli_close($conn);
?>