<?php
// ===========================
//  Darbic — Delete Account
//  POST: visitor_id
// ===========================

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

$visitor_id = intval($_POST['visitor_id'] ?? 0);

if ($visitor_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid visitor ID"]);
    exit;
}


// 1. eventhistory
$d1 = mysqli_prepare($conn, "DELETE FROM eventhistory WHERE visitor_id=?");
mysqli_stmt_bind_param($d1, "i", $visitor_id);
mysqli_stmt_execute($d1);
mysqli_stmt_close($d1);

// 2. notifications
$d2 = mysqli_prepare($conn, "DELETE FROM notification WHERE visitor_id=?");
mysqli_stmt_bind_param($d2, "i", $visitor_id);
mysqli_stmt_execute($d2);
mysqli_stmt_close($d2);

// 3. assistance requests
$d3 = mysqli_prepare($conn, "DELETE FROM assistancerequest WHERE visitor_id=?");
mysqli_stmt_bind_param($d3, "i", $visitor_id);
mysqli_stmt_execute($d3);
mysqli_stmt_close($d3);

// 4. visitorassignment المرتبطة بتكتاته
$d4 = mysqli_prepare($conn, "
    DELETE va FROM visitorassignment va
    JOIN ticket t ON va.ticket_id = t.ticket_id
    WHERE t.visitor_id = ?
");
mysqli_stmt_bind_param($d4, "i", $visitor_id);
mysqli_stmt_execute($d4);
mysqli_stmt_close($d4);

// 5. tickets
$d5 = mysqli_prepare($conn, "DELETE FROM ticket WHERE visitor_id=?");
mysqli_stmt_bind_param($d5, "i", $visitor_id);
mysqli_stmt_execute($d5);
mysqli_stmt_close($d5);

// 6. visitor
$d6 = mysqli_prepare($conn, "DELETE FROM visitor WHERE visitor_id=?");
mysqli_stmt_bind_param($d6, "i", $visitor_id);
mysqli_stmt_execute($d6);

if (mysqli_stmt_affected_rows($d6) > 0) {
    echo json_encode(["success" => true, "message" => "Account deleted successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Visitor not found"]);
}

mysqli_stmt_close($d6);
mysqli_close($conn);
?>