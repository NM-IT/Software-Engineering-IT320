<?php
// ===========================
//  Darbic — Update Profile
//  POST: visitor_id, full_name, email, phone
// ===========================

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

$visitor_id = intval($_POST['visitor_id'] ?? 0);
$full_name  = trim($_POST['full_name']    ?? '');
$email      = trim($_POST['email']        ?? '');
$phone      = trim($_POST['phone']        ?? '');

if ($visitor_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid visitor ID"]);
    exit;
}
if (empty($full_name) || empty($email) || empty($phone)) {
    echo json_encode(["success" => false, "message" => "All fields are required"]);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["success" => false, "message" => "Invalid email format"]);
    exit;
}

$check = mysqli_prepare($conn, "SELECT visitor_id FROM visitor WHERE email = ? AND visitor_id != ?");
mysqli_stmt_bind_param($check, "si", $email, $visitor_id);
mysqli_stmt_execute($check);
mysqli_stmt_store_result($check);

if (mysqli_stmt_num_rows($check) > 0) {
    echo json_encode(["success" => false, "message" => "Email already in use"]);
    mysqli_stmt_close($check);
    exit;
}
mysqli_stmt_close($check);

// Update
$stmt = mysqli_prepare($conn, "UPDATE visitor SET full_name=?, email=?, phone=? WHERE visitor_id=?");
mysqli_stmt_bind_param($stmt, "sssi", $full_name, $email, $phone, $visitor_id);

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["success" => true, "message" => "Profile updated successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Update failed: " . mysqli_error($conn)]);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>